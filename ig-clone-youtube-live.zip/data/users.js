export const USERS = [
  { user: 'Monu Nindaniya', image: 'https://i.pinimg.com/originals/ae/43/de/ae43de21164ac2ec26ee3cd84531eade.jpg' },
  { user: 'Parveen', image: 'https://www.fubiz.net/wp-content/uploads/2014/04/Macro-Photography-by-Milki-Asai12.jpg' },
  { user: 'Sachin', image: 'https://i.pinimg.com/originals/2f/e7/71/2fe7716eeafe61ee97483675f691921c.jpg/' },
  { user: 'Sonu', image: 'https://live.staticflickr.com/7327/9423555274_cbe28a18e8_b.jpg' },
  { user: 'Pardeep', image: 'https://cdn-icons-png.flaticon.com/512/219/219983.png' },
  { user: 'Veeru', image: 'https://wallpapers.com/images/hd/dragonfly-with-water-droplets-5q6gq2pyo5dj8xgh.jpg' },
  { user: 'Jony', image: 'https://cdn-icons-png.flaticon.com/512/219/219983.png' },
  { user: 'Sant', image: 'https://cdn-icons-png.flaticon.com/512/219/219983.png' },
  { user: 'Sagar', image: 'https://cdn-icons-png.flaticon.com/512/219/219983.png' },
]