import { USERS } from "./users"

export const POSTS = [
    {
        imageUrl: 'https://www.fonstola.ru/images/201911/fonstola.ru_360046.jpg',
        userName: USERS[0].user,
        likes: '500k',
        caption: 'hello brother how are you. from where you are. will you hear the great news about this website in the  future  and will be able to do that if you are interested then call me',
        profilePicture: USERS[0].image,
        comments: [
            {
                user: 'CUser1',
                comment: 'Kaisa h bhai'
            },
            {
                user: 'CUser2',
                comment: 'Or Brother Kaisa h'
            },
            {
                user: 'CUser1',
                comment: 'Londe Kaisa H'
            },
        ],
    },
    {
        imageUrl: 'https://thumbs.dreamstime.com/b/environment-earth-day-hands-trees-growing-seedlings-bokeh-green-background-female-hand-holding-tree-nature-field-gra-130247647.jpg',
        userName: USERS[1].user,
        likes: 1000,
        caption: '',
        profilePicture: USERS[1].image,
        comments: [
            {
                user: 'CUser1',
                comment: 'Kaisa h bhai'
            },
            {
                user: 'CUser2',
                comment: 'Or Brother Kaisa h'
            },
            {
                user: 'CUser1',
                comment: 'Londe Kaisa H'
            },
        ],
    },
    {
        imageUrl: 'https://images.pexels.com/photos/3408744/pexels-photo-3408744.jpeg',
        userName: USERS[2].user,
        likes: 1000,
        caption: '',
        profilePicture: USERS[2].image,
        comments: [
            {
                user: 'CUser1',
                comment: 'Kaisa h bhai'
            },
            {
                user: 'CUser2',
                comment: 'Or Brother Kaisa h'
            },
            {
                user: 'CUser1',
                comment: 'Londe Kaisa H'
            },
        ],
    },
    {
        imageUrl: 'https://images.pexels.com/photos/3408744/pexels-photo-3408744.jpeg',
        userName: USERS[3].user,
        likes: 1000,
        caption: '',
        profilePicture: USERS[3].image,
        comments: [
            {
                user: 'CUser1',
                comment: 'Kaisa h bhai'
            },
            {
                user: 'CUser2',
                comment: 'Or Brother Kaisa h'
            },
            {
                user: 'CUser1',
                comment: 'Londe Kaisa H'
            },
        ],
    },
]