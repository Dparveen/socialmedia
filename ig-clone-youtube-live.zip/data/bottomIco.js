export const BottomtabIcons = [
    {
        name: 'home',
        active: 'https://img.icons8.com/fluency-systems-regular/60/FF0000/home.png',
        inactive: 'https://img.icons8.com/fluency-systems-regular/60/ffffff/home.png'
    },
    {
        name: 'search',
        active: 'https://img.icons8.com/fluency-systems-regular/60/FF0000/search.png',
        inactive: 'https://img.icons8.com/fluency-systems-regular/60/ffffff/search.png'
    },
    {
        name: 'add',
        active: 'https://img.icons8.com/fluency-systems-regular/60/FF0000/plus.png',
        inactive: 'https://img.icons8.com/fluency-systems-regular/60/ffffff/plus.png'
    },
    {
        name: 'reels',
        active: 'https://img.icons8.com/fluency-systems-regular/60/FF0000/video.png',
        inactive: 'https://img.icons8.com/fluency-systems-regular/60/ffffff/video.png'
    },
    {
        name: 'user',
        active: 'https://img.icons8.com/fluency-systems-regular/60/FF0000/user.png', 
        inactive: 'https://img.icons8.com/fluency-systems-regular/60/ffffff/user.png'
    },
]