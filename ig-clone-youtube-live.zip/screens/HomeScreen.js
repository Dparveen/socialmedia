import { View, Text, SafeAreaView, StyleSheet, ScrollView } from 'react-native'
import React from 'react'
import Header from '../components/home/Header'
import Story from '../components/home/Story'
import Post from '../components/home/Post'
import { POSTS } from '../data/post'
import Bottomtabs from '../components/home/BottomTabs'
import { BottomtabIcons } from '../data/bottomIco'


const HomeScreen = () => {
    return (
        <SafeAreaView style={styles.container}>
            <Header />
            <Story />
            <ScrollView>
                {POSTS.map((post, index) => (
                    <Post post={post} key={index} />
                ))}
            </ScrollView>
           <Bottomtabs icons={BottomtabIcons} />
        </SafeAreaView>
    )
}

const styles = StyleSheet.create({
    container: {
        backgroundColor: 'black',
        flex: 1,
        textAlignVertical: 'center',
    },
})

export default HomeScreen