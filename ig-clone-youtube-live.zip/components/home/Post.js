import { View, Text, Image, StyleSheet, TouchableOpacity } from 'react-native'
import React from 'react'
import { Divider } from 'react-native-elements/dist/divider/Divider'


const postFooterIcons = [
  {
    name: 'like',
    likeImage: 'https://img.icons8.com/fluency-systems-regular/60/ffffff/like.png',
    likedImage: 'https://img.icons8.com/fluency-systems-regular/60/fa314a/like.png',
  },
  {
    name: 'comment',
    cImage: 'https://img.icons8.com/fluency-systems-regular/60/ffffff/chat.png',
  },
  {
    name: 'share',
    sImage: 'https://img.icons8.com/fluency-systems-regular/60/ffffff/share.png',
  },
  {
    name: 'save',
    saveImage: 'https://img.icons8.com/fluency-systems-regular/60/ffffff/save.png',
  },
]


const Post = ({ post }) => {
  return (
    <View style={{ marginBottom: 30 }}>
      <Divider width={1} orientation='vertical' />
      <PostHeader post={post} />
      <PostImage post={post} />
      <View style={{ marginTop: 15, marginLeft: 5, }}>
        <PostFooter />
        <Likes post={post} />
        <PostData post={post} />
        <Commentset post={post} />
        <Comment post={post} />
      </View>
    </View>
  )
}


const PostHeader = ({ post }) => (
  <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', margin: 5 }}>
    <View style={{ flexDirection: 'row', alignItems: 'center' }}>
      <Image source={{ uri: post.profilePicture }} style={styles.Story} />
      <Text style={styles.StoriesText}>{post.userName}</Text>
    </View>
    <Text style={{ fontWeight: '900', color: 'white' }}>...</Text>
  </View>
)

const PostImage = ({ post }) => (
  <View style={{ height: 320, width: '100%' }}>
    <Image source={{ uri: post.imageUrl }} style={styles.PostImage} />
  </View>
)

const PostFooter = () => (
  <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}>
    <View style={{ flexDirection: 'row', width: 20, height: 20, justifyContent: 'space-between' }}>
      <Icon imgStyle={styles.Icon} imgSource={postFooterIcons[0].likeImage} />
      <Icon imgStyle={styles.Icon} imgSource={postFooterIcons[1].cImage} />
      <Icon imgStyle={styles.Icon} imgSource={postFooterIcons[2].sImage} />
    </View>
    <View style={{ flex: 1, alignItems: 'flex-end' }}>
      <Icon imgStyle={styles.Icon} imgSource={postFooterIcons[3].saveImage} />
    </View>
  </View>
)

export const Icon = ({ imgStyle, imgSource }) => (
  <TouchableOpacity>
    <Image style={imgStyle} source={{ uri: imgSource }} />
  </TouchableOpacity>
)

const Likes = ({ post }) => (
  <View>
    <Text style={{ color: 'white' }} >{post.likes.toLocaleString('en') + ' likes'}</Text>
  </View>
)

const PostData = ({ post }) => (
  <View>
    <Text style={{ color: 'white', marginLeft: 4, }}>{post.user}</Text>
    <Text style={{ color: 'white' }} >
      {post.caption.length > 127 ? post.caption.slice(0, 127).toLocaleString() + ' ...' : post.caption.toLocaleString()}
    </Text>
  </View>
)

const Commentset = ({ post }) => (
  <View style={{ marginTop: 5, }}>
    {!!post.comments.length && (
      <Text style={{ color: 'gray' }}>
        View{post.comments.length > 1 ? 'all' : ''} {post.comments.length} {' '}
        {post.comments.length > 1 ? 'comments' : 'comment'}
      </Text>
    )}
  </View>
)

const Comment = ({ post }) => (
  <>
    {post.comments.map((comment, index) => (
      <View key={index} style={{flexDirection: 'row', marginTop: 5,}}>
        <Text style={{ color: 'white' }}>
          <Text style={{ fontWeight: 600 }}>  {comment.user}</Text>
          {comment.comment}
        </Text>
      </View>
    ))}
  </>
)

const styles = StyleSheet.create({
  Story: {
    height: 30,
    width: 30,
    borderRadius: 50,
    borderWidth: 1,
    borderColor: 'red',
  },
  Icon: {
    height: 30,
    width: 30,
    marginLeft: 5,
  },
  StoriesText: {
    marginLeft: '7%',
    color: 'white',
  },
  PostImage: {
    resizeMode: 'cover',
    height: '100%',
  },
  footericon: {
    width: 33,
    height: 33,
  }

})
export default Post