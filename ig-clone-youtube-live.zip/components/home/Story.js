import { View, Text, ScrollView, Image, StyleSheet, TouchableOpacity } from 'react-native'
import React from 'react'
import { USERS } from '../../data/users'


USERS
const Story = () => {
  return (
    <View style={{ marginTop: 3, }}>
      {/* <Text style={{ color: 'white' }}></Text> */}
      <ScrollView
        horizontal
        showHorizontalScrollIndicator={false} >
        {USERS.map((story, index) => (
          <TouchableOpacity >
            <View key={index} style={{ alignItems: 'center' }}>
              <Image style={styles.Stories} source={{ uri: story.image }} />

              <Text style={{ color: 'white' }}>{
                story.user.length > 8 ? story.user.slice(0, 7).toLocaleLowerCase() + '...'
                  : story.user.toLocaleLowerCase()}</Text>
            </View>
          </TouchableOpacity>
        ))}
      </ScrollView>
    </View>
  )
}

const styles = StyleSheet.create({

  Stories: {
    height: 60,
    width: 60,
    borderRadius: 50,
    marginLeft: 5,
    borderWidth: 2,
    borderColor: 'green',
  },
  StoriesText: {
    color: '#fff',
  }
})

export default Story