import { View, Image, Text, StyleSheet, TouchableOpacity } from 'react-native'
import React, { useState } from 'react'
import { Divider } from 'react-native-elements'

const Bottomtabs = ({ icons }) => {
    const [activeTab, setactiveTab] = useState('add')
    const Icon = ({ datas }) => (
        <TouchableOpacity onPress={() => setactiveTab(datas.name)}>
            <Image style={styles.icon} source={{ uri: activeTab === datas.name ? datas.active : datas.inactive }} />
        </TouchableOpacity>
    )
    return (
        <View>
            <Divider width={1} orientation='horizontal' />
            <View style={styles.cont}>
                {icons.map((icon, index) => (
                    <Icon key={index} datas={icon} />
                ))}
            </View>
        </View>
    )
}

const styles = StyleSheet.create({
    icon: {
        height: 30,
        width: 30,
    },
    cont: {
        flexDirection: 'row', justifyContent: 'space-between', height: 50, padding: 10
    }
})

export default Bottomtabs