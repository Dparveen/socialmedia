import { View, Text, Image, SafeAreaView, StyleSheet, TouchableOpacity, } from 'react-native'
import React from 'react'

const Header = () => {
  return (
    <SafeAreaView style={styles.container}>
      <TouchableOpacity>
      <Image 
      style={styles.logo} 
      source={require('../../assets/logo.png')} />
      </TouchableOpacity>
      <View style={styles.iconcontainer}>
      <TouchableOpacity>
          <Image style={styles.icon}
          source={{
            uri: 'https://img.icons8.com/fluency-systems-regular/60/ffffff/plus-2-math.png',
          }} />
      </TouchableOpacity>
      <TouchableOpacity>
      <View style={styles.notifiBage}>
                  <Text style={styles.notifiText}>1139</Text>
        </View>
          <Image style={styles.icon}
          source={{
            uri: 'https://img.icons8.com/fluency-systems-regular/60/ffffff/like--v1.png',
          }} />
      </TouchableOpacity>
      <TouchableOpacity>
        <View style={styles.notifiBage}>
            <Text style={styles.notifiText}>679</Text>
        </View>
          <Image style={styles.icon}
          source={{
            uri: 'https://img.icons8.com/fluency-systems-regular/60/ffffff/facebook-messenger.png',
          }} />
      </TouchableOpacity>


      </View>
    </SafeAreaView>
  )
}

const styles = StyleSheet.create({
  container:{
      justifyContent: 'space-between',
      alignItems: 'center',
      flexDirection: 'row',
      marginHorizontal: 0,
      marginLeft: 10,
   },
  logo: {
    width: 80,
    height: 50,
    resizeMode: 'contain',
  },

  iconcontainer: {
    flexDirection: 'row',
  },
  icon:{
    height: 25,
    width: 25,
    resizeMode: 'contain',
    marginLeft: '1%',
    marginBottom: '60%',
  },
  notifiBage:{
      backgroundColor: 'red',
      position:'absolute',
      left: '50%',
      bottom: '80%',
      width: 20,
      height: 15,
      borderRadius: 25,
      alignItems: 'center',
      justifyContent: 'center',
      zIndex: 1000,
  },
  notifiText:{
    color: 'white',
    fontWeight: 'bold',
    fontSize: '8px',
  },

})

export default Header