import { View, Text } from "react-native";
import HomeScreen from "./screens/HomeScreen";

export default function App() {
  return <HomeScreen />
}
